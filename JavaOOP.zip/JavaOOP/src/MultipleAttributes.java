public class MultipleAttributes {
    String firstName= "John";
    String lastName= "Doe";
    int age= 24;

    public static void main(String[] args) {
        MultipleAttributes myObj= new MultipleAttributes();
        System.out.println("Name: " + myObj.firstName+ " " + myObj.lastName);
        System.out.println("Age: " + myObj.age);
    }
}
