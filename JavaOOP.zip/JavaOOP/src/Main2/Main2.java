package Main2;

public class Main2 {
    //Create a fullThrottle() method
    public void fullThrottle(){
        System.out.println("This car is going as fast as it can!");
    }
    public void speed(int maxSpeed){
        System.out.println("Max speed is: " + maxSpeed);
    }
}

