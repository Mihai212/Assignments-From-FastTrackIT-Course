package Main2;

import Main2.Main2;

public class Second2 {

    public static void main(String[] args) {
        Main2 myCar = new Main2(); // Create a myCar object
        myCar.fullThrottle(); // Call the fullThrottle() method
        myCar.speed(200); //Call the speed() method
    }
}