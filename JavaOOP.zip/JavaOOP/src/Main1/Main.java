package Main1;

public class Main {
    static void myMethod() {
        System.out.println("Hello World");
    }

    public static void main(String[] args) {
        myMethod();
    }

    int x = 5;
    int y=  3;

    }

