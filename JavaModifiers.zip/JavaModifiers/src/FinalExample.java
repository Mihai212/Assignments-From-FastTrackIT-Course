
public class FinalExample {
  final int x= 10;
  final double PI= 3.14;

    public static void main(String[] args) {
        FinalExample myObj= new FinalExample();
        myObj.x=50; //will generate an error can not assign a value
        myObj.PI=25; //will generate an error can not assign a value
        System.out.println(myObj.x);
        System.out.println(myObj.PI);

    }
}