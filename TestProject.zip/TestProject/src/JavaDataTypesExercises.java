public class JavaDataTypesExercises {
    public static void main(String[] args) {

        int a= 5;
        a--;
        System.out.println(a);

int b= 5;
b+= 3;
        System.out.println(b);

int c= 5;
int d= 3;
        System.out.println(c<d);

String p="ASDAWGA WGSRRHR HTYd awdwadawNFTN";
        System.out.println("The lenght of txt string is: "+p.length());

        String myUpper= "Hello Mihai";
        String myLower= "HeLlO MiHaI";
        System.out.println(myUpper.toUpperCase());
        System.out.println(myLower.toLowerCase());

String txt= "Please locate where locate occurs";
        System.out.println(txt.indexOf("o"));

        String myFirstName= "Dobos";
        String myLastName= "Mihai";
        System.out.println(myFirstName+" "+myLastName);

        //Specials characthers
        String vikings = "We are the so-called \"Vikings\" from the north.";
        System.out.println(vikings);

        String alright = "It\'s alright.";
        System.out.println(alright);

        String backslash = "The character \\ is called backslash.";
        System.out.println(backslash);

        //Maths
        //Highest and Min Value
        double firstNumber= Math.max(5, 10);
        System.out.println(firstNumber);
        double secondNumber= Math.min(5, 10);
        System.out.println(secondNumber);

        //Square
        double thirdNumber=Math.sqrt(64);
        System.out.println(thirdNumber);

        //Random Numbers 0-100

            int randomNum = (int)(Math.random() * 101);
            System.out.println(randomNum);

            int randomNum1 = (int)(Math.random() * 13011);
            System.out.println(randomNum1);

            double randomNum2 = (double)(Math.random() * 101);
            System.out.println(randomNum2);



    }
}
