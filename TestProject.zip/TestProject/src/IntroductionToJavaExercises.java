public class IntroductionToJavaExercises {
    /*1. Write a Java program to print 'Hello' on screen and then print your name on a separate line*/
    public static void main(String[] args) {

        //Modul in care declaram datele apoi le printam

        String a= "Hello";
     String b = "yourName, Mihai";
        System.out.println(a);
        System.out.println(b);

        //Modul in care scriem si printam datele direct
        System.out.println("Hello");
        System.out.println("yourName, Mihai");

        /*2. Write a Java program to print the sum of two numbers*/
        //Prima metoda
        int d= 74;
        int e= 36;
        int f= d+e;
        System.out.println(f);

        /*A doua metoda
        int g= 74;
        int h= 36;
        System.out.println(g+h);*/

        /*3. Write a Java program to divide two numbers and print on the screen*/

        int i= 60;
        int j= 3;
        System.out.println(i/j);

        /*4. Write a Java program to print the result of the following operations
                  a. -5 + 8 * 6
                  b. (55+9) % 9
                  c. 20 + -3*5 / 8
                  d. 5 + 15 / 3 * 2 - 8 % 3*/
        //a. -5 + 8 * 6
        int k= -5;
        int l= 8;
        int m= 6;
        int n= k+l*m;
        System.out.println(n);

        // b. (55+9) % 9
int o= 55;
int p= 9;
int q= 9;
int r= (o+p) % q;
        System.out.println(r);

        //c. 20 + -3*5 / 8
int ab= 20;
int bc= -3;
int cd= 5;
int de= 8;
int ef= ab+bc*cd/de;
        System.out.println(ef);

        // d. 5 + 15 / 3 * 2 - 8 % 3

        int fg = 15;
        int gh= 3;
        int hi= 2;
        int ij= cd+fg/gh*hi-de%gh;
        System.out.println(ij);

        /*1. Create a variable named carName and assign the value Volvo to it*/
String carName= "Volvo";

       /* 2. Create a variable named maxSpeed and assign the value 120 to it*/
int maxSpeed= 120;

        /*3. Display the sum of 5 + 10, using two variables: x and y.*/
int x= 5;
int y= 10;
int XY= x+y;
        System.out.println(XY);

       /* 4. Create a variable called z, assign x + y to it, and display the result.*/
    String z= "x+y";
        System.out.println(z);

        /*5. Create a greeting variable of type String and assign it the value Hello.*/
String greeting= "Hello";
        System.out.println(greeting);

        /*6. Example below: Write a Java program to compute the specified expressions and print the output.
Specified Expression : (25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5) */
        System.out.println((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5));
    }
}
