public class Test {
    public static void main(String[] args) {
        /*System.out.println("Test");
        System.out.println(1);
        System.out.println("Test123456789");
        ///Operatie Matematica
        System.out.println(1+1);

        //Text
        System.out.println("1+1");
      int a = 1;
      int b = 2;
        System.out.println(a + b);*/

      /* Comananda "Sting" stocheaza TEXT
        String FirstValue= "Test";*/

        String FirstValue= "Test 1";
        int SecondValue= 10;
        double ThirdValue= 1.5;
        char ForthValue= 'T';
        boolean FifthValue= true;
        boolean SixthValue= false;

        System.out.println(ForthValue);
        System.out.println(ForthValue + FirstValue + ForthValue);
        System.out.println(FifthValue);
        System.out.println(SixthValue);

        final int myNum= 15;
        System.out.println(myNum);

        int a=15;
        int b=20;
        int c= 12;
        System.out.printf("Rezultatul este:");
        System.out.println(a+b+c);

        boolean boolvalue= true;
        System.out.println(boolvalue);

        //Data Types
        float myFloatNum = 5.99f; // Floating point number
        char myLetter = 'D'; // Character
        boolean myBool = true; // Boolean
        String myText = "Hello"; // String


    }
}
