public class CodGresitCorectat {

//corectati greselile din aceasta clasa pentru a putea fi rulata
public static void main(String[] args) {

        System.out.println(19.9);
        System.out.println("text");
        System.out.println(12);
        System.out.println("text nou");

        double doubleNumber = 1.1;
        double b = 23.3;

        System.out.println(doubleNumber + b);

        char singleChar = 'c';
        System.out.println(singleChar);
        boolean boleanExample = true;
        System.out.println(boleanExample);

        String name = "John";
        System.out.println("hello" + name);

        String firstName = "John";
        String lastName = "Doe";
        String fullName = firstName+lastName;
        System.out.println(fullName);

        int x = 5;
        int y = 6;
        System.out.println(x+y);

       int a= 50;
       int ab= 50;
       int ac= 50;
        System.out.println(a+ab+ac);

/* rezolvati eroarea de mai sus pentru a putea printa rezultatul lui 50+50+50.*/

}
}