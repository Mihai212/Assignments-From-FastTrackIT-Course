public class AssignmentLab8Rezolved {
    public static void main(String[] args) {

//Add the correct data type for the following variables:

        int myNum= 9;
        float myFloatNum= 8.99f;
        char myLetter= 'A';
        boolean myBool= false;
        String myText= "Hello World";

//Multiply 10 with 5, and print the result.

int firstNumberMultiply= 10;
int secondNumberMultiply= 5;
int multiply= firstNumberMultiply * secondNumberMultiply;
        System.out.println(multiply);

//Make the sum of 10 with 5.

int firstNumberSum= 10;
int secondNumberSum= 5;
int sum= firstNumberSum + secondNumberSum;
        System.out.println(sum);

//Subtract 10 with 5.

        int firstNumberSub= 10;
        int secondNumberSub= 5;
        int sub= firstNumberSub - secondNumberSub;
        System.out.println(sub);

 //Divide 10 with 5.

        int firstNumberDivide= 10;
        int secondNumberDivide= 5;
        int divide= firstNumberDivide / secondNumberDivide;
        System.out.println(divide);

//Increment 10 by 1.

int incNumber= 10;
incNumber++;
        System.out.println(incNumber);

// int x = 10; int y = 5. Use comparison operators such as ==, !=, >, <, >=, <= on these two values.

        int a = 10;
        int b = 5;
        System.out.println(a==b);
        System.out.println(a>b);
        System.out.println(a<b);
        System.out.println(a>=b);
        System.out.println(a<=b);

// Use logical operators such as &&, ||, ! on these two values

        int x= 10;
        int y= 5;
        System.out.println(y<10 && x<=5);
        System.out.println(y>=10 || x==5);
        System.out.println(!(y<=10 && x>5));
        System.out.println(y<10 && x>5);
        System.out.println(y>=10 || x<=5);
        System.out.println(!(y>=10 && x!=5));

//Fill in the missing part to create a greeting variable of type String and assign it the value Hello.

        String greeting= "Hello";

//Use the correct method to print the length of the txt string.

        String firstTxt= "Hello";
System.out.println(firstTxt.length());

//Convert the value of txt to upper case.

        System.out.println(firstTxt.toUpperCase());

//Use the correct operator to concatenate two strings:

String firstName= "John ";
String lastName="Doe";
        System.out.println(firstName+lastName);

//Use the correct method to concatenate two strings:

        System.out.println(firstName.concat(lastName));

//Return the index (position) of the first occurrence of "e" in the following string:

String secondTxt= "Hello Everybody";
        System.out.println(secondTxt.indexOf("e"));

//Use the correct method to find the highest value of x and y.

        int z= 5;
        int p= 10;
 double highestZP= Math.max(5,10);
        System.out.println(highestZP);

//Use the correct method to find the square root of x.

       double xy= Math.sqrt(16);
        System.out.println(xy);

//Use the correct method to return a random number between 0 (inclusive), and 1 (exclusive)

  int randomNumber= (int) (Math.random() * 2);
        System.out.println(randomNumber);
    }
}
