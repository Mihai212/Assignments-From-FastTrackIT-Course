public class JavaElseStatement {
    public static void main(String[] args) {

     int time= 20;
     if (time<18) {
         System.out.println("Good day.");
     }else {
         System.out.println("Good evening.");
     }

        int time2= 9;
        if (time2<10) {
            System.out.println("Good morning");
        }else if (time2<18) {
            System.out.println("Good day.");
        }else {
            System.out.println("Good evening");
        }
    }
}
