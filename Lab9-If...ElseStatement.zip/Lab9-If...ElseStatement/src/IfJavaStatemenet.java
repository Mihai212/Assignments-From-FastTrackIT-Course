public class IfJavaStatemenet {
    public static void main(String[] args) {

        if(20>=18){
            System.out.println("20 is greater than 18");
        }

int firstNumber= 10;
        int secondNumber= 20;
        if (firstNumber>secondNumber){
            System.out.println("first number is smaller than second number");
        }

int number= 10;
        if (number>0){
            System.out.println("The number is positive.");
        }
        System.out.println("Statement outside if block");

        String language= "Java";
        if(language=="Java"){
            System.out.println("Best Programming Language");
        }

    }
}
