import com.sun.tools.attach.AgentInitializationException;

import java.util.Scanner;
public class JavaUserInput2 {
    public static void main(String[] args) {

        Scanner myObj= new Scanner(System.in);
        System.out.println("Enter Your Name, Age, Salary");

        //String input
        String Name= myObj.nextLine();

        //Numerical input
        int age= myObj.nextInt();

        double Salary= myObj.nextDouble();

        //Output input by user

        System.out.println("Name: "+ Name);
        System.out.println("Age");
        System.out.println("Salary"+ Salary);









    }
}