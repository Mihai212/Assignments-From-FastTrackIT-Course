public class Main {
    public static void main(String[] args) {
        boolean doneHomework = true;
        boolean cleanedRoom = true;
        if (doneHomework && cleanedRoom) {
            System.out.println("You can not go out");
        } else {
            System.out.println("You can not go out");
        }
    }
}