public class JavaExercisesIfAndElse {
    public static void main(String[] args) {

        //Print "Hello World" if x is greater than y.

        int x = 50;
        int y = 10;
        if (x > y) {
            System.out.println("Hello World");
        }

        //Print "Hello World" if a is equal with b

        int a = 50;
        int b = 50;
        if (a == b) {
            System.out.println("Hello World");
        }
        //Print "Yes" if c is equal to d, otherwise print "No"

        int c = 50;
        int d = 30;
        if (c == d) {
            System.out.println("Yes");
        } else {
            System.out.println("No");


        //Print "1" if e is equal to f, print "2" if e is greater than f, otherwise print "3"

            int e = 50;
            int f = 50;
            if (e == f)
            {System.out.println("1");}
            else if (e>f)
            {System.out.println("2");}
            else
            {System.out.println("3");}

    }
}
}