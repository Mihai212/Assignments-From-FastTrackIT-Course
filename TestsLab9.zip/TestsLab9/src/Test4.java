//The following code should print if x is in the range of 0 to 10 (including 0 and 10). However, the code has errors.
// Fix the errors so that the code runs as intended.
public class Test4 {
    public static void main(String[] args) {
        int x = 3;
        if (x >= 0 && x <= 10) {
            System.out.println("x is between 0 and 10 inclusive");
        } else {
            System.out.println("x is either less than 0 or greater than 10");
        }
    }
}