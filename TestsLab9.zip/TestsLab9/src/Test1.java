//1.Fix the following code to run:
public class Test1{
    public static void main(String[] args) {
        int x = 3;
        if (x > 0){
            System.out.println("x is greater than 0");
        }else{
            System.out.println("x is less than or equal 0");
        }
    }
}