//Finish the code below so that it prints You can go out if you have a ride or if you can walk and otherwise
// prints You can't go out. Use a logical or to create a complex conditional.
public class Test6
{
    public static void main(String[] args)
    {
        boolean canWalk = true;
        boolean haveRide = false;
        if (canWalk || haveRide){
            System.out.println("You can go out");}
        else {
            System.out.println("You can't go out");
        }
    }
}
