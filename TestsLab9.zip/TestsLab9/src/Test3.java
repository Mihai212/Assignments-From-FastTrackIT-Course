//The following code should print if you can go out or not. You can go out if you have done your homework and
// cleaned your room. However, the code has errors. Fix the code so that it compiles and runs correctly.
public class Test3 {
    public static void main(String[] args) {
        boolean doneHomework = true;
        boolean cleanedRoom = true;
        if (doneHomework && cleanedRoom) {
            System.out.println("You can not go out");
        } else {
            System.out.println("You can go out");
        }
    }
}
