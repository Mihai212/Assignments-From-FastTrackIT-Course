//Finish the code to print It is freezing if the temperature is below 30, It is cold if it is below 50, It is nice out if it
// is below 90, or It is hot.
public class Test9 {
    public static void main(String[] args) {
        int temp = 100;
        int a = 30;
        int b = 50;
        int c = 90;
        if ( temp < a ) {
            System.out.println("It is freezing");
        } else if (temp < b) {
            System.out.println("It is cold");
        } else if (temp < c) {
            System.out.println("It is nice out");
        } else {
            System.out.println("It is hot");
        }
    }
}
