//The following code should check your guess against the answer and print that it is too low, correct, or too
//high. However, the code has errors. Fix the code so that it compiles and runs correctly.
public class Test2 {
    public static void main(String[] args) {
        int guess = 7;
        int answer = 9;

        if (guess < answer) {
            System.out.println("Your guess is too low");
        } else if (guess == answer) {
            System.out.println("You are correct!");
        } else {
            System.out.println("Your guess is too high");
        }
    }
}