//The following code should print if x is less than 0, equal to 0, or greater than 0. Finish it to work correctly.
public class Test5
{
    public static void main(String[] args)
    {
        int x = -3;
        if (x < 0){
            System.out.println("x is less than 0");}
        else if (x==0){
            System.out.println("x is equal to 0");}
        else {
            System.out.println("x is greater than 0");
        }
    }
}
