//Finish the code below to print your grade based on your score. The score is an A if you scored 92 or higher, a B
// if you scored 82 to 91, a C if you scored 72 to 81, a D if you scored a 62 to 71, or an E.

public class Test10
{
    public static void main(String[] args)
    {
        double score = 67;
        int score1= 92;
        int score2= 82;
        int score3= 72;
        int score4= 62;

        if (score>=score1){
            System.out.println("The score is an A");}
        else if (score>=score2){
            System.out.println("The score is an B");}
        else if (score>=score3){
            System.out.println("The score is an B");}
        else if (score>=score4){
        System.out.println("The score is an D");}
    else{
        System.out.println("The score is an E");}
        }
    }

