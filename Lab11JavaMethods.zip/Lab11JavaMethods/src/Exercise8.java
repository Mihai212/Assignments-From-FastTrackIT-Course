public class Exercise8 {
    static void myMethod(String fname){
        System.out.println(fname+ "Doe");
    }

    public static void main(String[] args) {
        myMethod("John ");
    }
}
