public class ReturnValues4 {
    static int myMethod(int x){
        return 5 + x;
    }
    public static void main(String[] args) {
        System.out.println(myMethod(5));
    }
}
