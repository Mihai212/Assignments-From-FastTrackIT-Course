public class MultipleParameters3 {
    static void multipleParametres(String Nume, int Age){
        System.out.println(Nume+ " is " + Age + ". Aceasta este varsta fictiva.");}

    public static void main(String[] args) {
        multipleParametres("Ion", 5);
        multipleParametres("Ana", 8);
        multipleParametres("Alexandra", 31);
    }
}
