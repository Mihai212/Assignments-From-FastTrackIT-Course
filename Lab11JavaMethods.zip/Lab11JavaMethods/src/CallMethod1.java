
public class CallMethod1 {
    static void myMethod() {
        System.out.println("I just got executed");
    }
    public static void main(String[] args){
      myMethod();
        myMethod();
        myMethod();
        myMethod();
    }
    }

