public class IfElseMethods7 {
    static void checkAge(int Age){
        if (Age < 18){
            System.out.println("Acces denied - You are not old enough!");
        }else {
            System.out.println("Acces granted- You are old enough!");
        }
    }

    public static void main(String[] args) {
        checkAge(11);
        checkAge(23);
        checkAge(66);
    }
}
