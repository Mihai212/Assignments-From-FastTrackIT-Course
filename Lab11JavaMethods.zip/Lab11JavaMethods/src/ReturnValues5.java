public class ReturnValues5 {
    static int myMethod (int x){
        return 5+x;
    }
    static int myMethod2 (int x, int y){
        return x + y;
    }
    static int myMethod3 (char x, char y ){
        return x + y;
    }

    public static void main(String[] args) {
        int z= myMethod2(10, 1);
        System.out.println(z);
        System.out.println(myMethod(3));
        System.out.println(myMethod2(1,2));
        System.out.println(myMethod3('a','d'));
    }
}
