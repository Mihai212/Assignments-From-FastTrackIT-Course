public class MethodParameters2 {
    static void myMethod(String prenume){
        System.out.println(prenume + " Pop");
    }

    public static void main(String[] args) {
        myMethod("Ion");
        myMethod("Ana");
    }
}
